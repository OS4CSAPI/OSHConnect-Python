# ODAS → CSAPI Semantic & Field-Level Profile (v1.0)

**Version:** 1.0  
**Date:** 2026-02-26  

This profile pack provides:
- A **field register** for CSAPI Part 1 + Part 2 resources used in the ODAS mic-array model
- SWE Common **resultSchema** objects for ODAS SSL and SST outputs + normalized per-track updates
- Example GeoJSON/JSON payloads placed near your provided Ft Huachuca / Huachuca City coordinate

## Modeling summary

- MA-1..MA-3 are `System` features (`featureType="sosa:Sensor"`).
- The *ultimate* Feature of Interest is a shared AOI polygon (scene/context FOI).
- Detected tracks are modeled as `SamplingFeature` resources (`featureType="sosa:Sample"`) created on first detection and persisted via `validTime`.

## Included files

- `ODAS_CSAPI_Field_Register_v1.0.csv`
- `ODAS_CSAPI_ResultSchema_SSL_Potential_v1.0.json`
- `ODAS_CSAPI_ResultSchema_SST_TrackedScene_v1.0.json`
- `ODAS_CSAPI_ResultSchema_TrackUpdate_v1.0.json`
- `examples_ft_huachuca/*`

## Google Maps center point (from screenshot)

31.657006, -110.265897  
https://www.google.com/maps/search/?api=1&query=31.657006,-110.265897
