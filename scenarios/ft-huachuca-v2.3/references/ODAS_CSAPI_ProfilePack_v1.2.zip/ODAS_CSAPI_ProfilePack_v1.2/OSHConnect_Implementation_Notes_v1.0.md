# OSHConnect / OSH Node implementation notes (v1.0)

This profile pack is designed to be standards-first (CSAPI + SensorML + SWE Common).  
However, OSHConnect adds a few practical constraints when inserting datastreams and observations:

- **TimeSchema is required to be the first field** in a `DataRecordSchema` when creating datastream schemas in OSH.  
- For observations inserted via OSHConnect, **both `resultTime` and `phenomenonTime` are required**.

Source: OpenSensorHub documentation "Usage" page (OSHConnect).  
